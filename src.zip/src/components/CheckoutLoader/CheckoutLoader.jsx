import React from 'react';

const CheckoutLoader = () => {
  return <div>Cargando datos del pedido...</div>;
};

export default CheckoutLoader;
