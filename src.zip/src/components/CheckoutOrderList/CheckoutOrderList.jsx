import React from 'react';

const CheckoutOrderList = () => {
  return <div>Listado de pedidos</div>;
};

export default CheckoutOrderList;
